export class User {
    firstName: string;
    lastName: string;
    webmail?: string;
}
